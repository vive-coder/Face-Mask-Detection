import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
import os

# Paths
train_dir = os.path.join('dataset', 'train')
test_dir = os.path.join('dataset', 'test')

# Image preprocessing (kept simple for fast demo training)
train_datagen = ImageDataGenerator(rescale=1./255)
test_datagen = ImageDataGenerator(rescale=1./255)

train_data = train_datagen.flow_from_directory(
    train_dir, target_size=(150,150), batch_size=8, class_mode='binary'
)
test_data = test_datagen.flow_from_directory(
    test_dir, target_size=(150,150), batch_size=8, class_mode='binary'
)

# Tiny CNN (fast on CPU)
model = Sequential([
    Conv2D(16, (3,3), activation='relu', input_shape=(150,150,3)),
    MaxPooling2D(2,2),
    Conv2D(32, (3,3), activation='relu'),
    MaxPooling2D(2,2),
    Flatten(),
    Dense(64, activation='relu'),
    Dropout(0.3),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train quickly (few epochs)
history = model.fit(train_data, validation_data=test_data, epochs=3)

# Save model
model.save('mask_model_mini.h5')
print('✅ Model trained and saved as mask_model_mini.h5')
