# Face Mask Detection — Mini (Windows Ready)

A tiny, fast-to-run demo project for mask vs. no-mask classification using TensorFlow + OpenCV.

## Folder Structure
```
Face_Mask_Detection_Complete_Windows/
├─ dataset/
│  ├─ train/
│  │  ├─ with_mask/         # sample images included
│  │  └─ without_mask/
│  └─ test/
│     ├─ with_mask/
│     └─ without_mask/
├─ train_model.py
├─ test_model.py
├─ detect_mask_live.py
└─ requirements.txt
```

## Run (Windows / VS Code)
1. Open folder in VS Code → **Terminal → New Terminal**
2. Install libraries:
```
pip install -r requirements.txt
```
3. Train (fast ~ a minute):
```
python train_model.py
```
4. Test on one image (default sample):
```
python test_model.py
```
   Or test your own image:
```
python test_model.py path_to_your_image.jpg
```
5. Live webcam detection:
```
python detect_mask_live.py
```
Press **Q** to quit the webcam window.

> Note: Sample images are synthetic for speed. For better accuracy, swap the dataset with real photos (same folder names).

## Notes
- If webcam doesn't open, ensure no other app is using the camera.
- If TensorFlow install is slow, try a virtual environment:
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```
