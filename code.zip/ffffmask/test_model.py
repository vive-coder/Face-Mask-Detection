from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import sys
import os

# Allow passing an image path, else use a default sample from dataset
img_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join('dataset','test','with_mask','with_mask_test_1.jpg')

model = load_model('mask_model_mini.h5')

img = image.load_img(img_path, target_size=(150,150))
img_array = image.img_to_array(img) / 255.0
img_array = np.expand_dims(img_array, axis=0)

result = model.predict(img_array)
label = 'Mask' if result[0][0] < 0.5 else 'No Mask'

print(f'Image: {img_path} → Prediction: {label} ({result[0][0]:.4f})')
